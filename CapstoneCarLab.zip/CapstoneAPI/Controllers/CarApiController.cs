﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CapstoneAPI.Models;

namespace CapstoneAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private static List<Car> _cars = new List<Car>();

        [HttpGet]
        public IEnumerable<Car> Get()
        {
            return _cars;
        }

        [HttpPost]
        public IActionResult Post(Car car)
        {
            _cars.Add(car);
            return Created($"/api/car/{car.CarId}", car);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var car = _cars.FirstOrDefault(x => x.CarId == id);
            if (car == null)
            {
                return NotFound();
            }

            return Ok(car);
        }
    }
}