﻿using CarCap.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace CarCap.Services
{
  //need to add put action

    public class ApiCarService : ICarsService
    {
        private readonly HttpClient _client;

        public ApiCarService(HttpClient client)
        {
            _client = client;
        }

        public async Task Create(Car car)
        {
            await _client.PostAsJsonAsync("cars", car);
        }

        public async Task<Car> Get(int id)
        {
            return await _client.GetFromJsonAsync<Car>($"car/{id}");
        }

        

        public async Task<IEnumerable<Car>> GetAll()
        {
            return await _client.GetFromJsonAsync<IEnumerable<Car>>("car");
        }
    }
}
